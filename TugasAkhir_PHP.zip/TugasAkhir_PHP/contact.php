<div class="page">
    <h2>Hubungi Kami</h2>
    <p>Telp: 012-456789
        <br>WA: 08987654321
        <br>Senin - Minggu
    24 Jam</p>
 
    <p> Jl. Darkhold, 
        Earth-500, 
        Multiverse
    11111</p>
</div>
<div class="page">
    <p>Kami menawarkan pakaian yang akan menyuguhkan Anda kenyamanan saat memakainya di Universe manapun.</p>
    <p>Diskon 10% dengam minimal pembelian 20.000 Drachma, Pesan Sekarang!</p>
</div>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Produk</title>
</head>
<body>
  <p>
      <figure> 
          <a href="http://localhost:8080/TugasAkhir_PHP/index.php?page=checkout">
          <center><img src="images/kaos.jpg" width="300" height="300" alt="Kaos"/></center>
        </a>
          <figcaption><center>Land of Gente Shirt</center></figcaption>
          <figcaption><center>10.000 Drachma</center></figcaption>
        </figure>
  </p><br>
  <p>
      <figure> 
          <a href="http://localhost:8080/TugasAkhir_PHP/index.php?page=checkout">
          <center><img src="images/sepatu.jpg" width="300" height="300" alt="Sepatu"/></center>
        </a>
          <figcaption><center>Land of Gente Sneakers</center></figcaption>
          <figcaption><center>30.000 Drachma</center></figcaption>
        </figure>
  </p><br>
  <p>
      <figure> 
          <a href="http://localhost:8080/TugasAkhir_PHP/index.php?page=checkout">
          <center><img src="images/celana.jpg" width="300" height="300" alt="Celana"/></center>
        </a>
          <figcaption><center>Land of Gente Sweatpants</center></figcaption>
          <figcaption><center>15.000 Drachma</center></figcaption>
        </figure>
  </p><br>
  <p>
      <figure> 
          <a href="http://localhost:8080/TugasAkhir_PHP/index.php?page=checkout">
          <center><img src="images/hoodie.jpg" width="300" height="300" alt="Hoodie"/></center>
        </a>
          <figcaption><center>Land of Gente Hoodie</center></figcaption>
          <figcaption><center>20.000 Drachma</center></figcaption>
        </figure>
  </p><br>
  <p>
      <figure> 
          <a href="http://localhost:8080/TugasAkhir_PHP/index.php?page=checkout">
          <center><img src="images/tas.jpg" width="300" height="300" alt="Tas"/></center>
        </a>
          <figcaption><center>Land of Gente Handbag</center></figcaption>
          <figcaption><center>25.000 Drachma</center></figcaption>
        </figure>
  </p><br>
  <p>
      <figure> 
          <a href="http://localhost:8080/TugasAkhir_PHP/index.php?page=checkout">
          <center><img src="images/topi.jpg" width="300" height="300" alt="Topi"/></center>
        </a>
          <figcaption><center>Land of Gente Bucket Hat</center></figcaption>
          <figcaption><center>5.000 Drachma</center></figcaption>
        </figure>
  </p>
</body>
</html>
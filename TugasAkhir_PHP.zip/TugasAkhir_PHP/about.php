<div class="page">
    <h2>Tentang Land of Gente</h2>
    <p>Telah dipercaya sebagai clothing brand kekinian di Multiverse yang mengutamakan kualitas. Jangan ragu untuk berbelanja di Land of Gente karena kepuasan pelanggan adalah prioritas utama.</p>
    <p>Kami hanya memproduksi pakaian dengan bahan terbaik. Kami juga memberikan jaminan uang kembali jika barang terbukti dikirim dalam kondisi rusak.</p>
</div>